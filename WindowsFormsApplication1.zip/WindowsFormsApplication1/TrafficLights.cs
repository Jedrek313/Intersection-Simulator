﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class TrafficLights
    {
        private int time;
        private int yellowTime = 30;
        private int leftTime = 90;
        private int normalTime = 120;
        private int totalTime;
        public TrafficLights()
        {
            time = 0;
            totalTime = yellowTime * 4 + leftTime * 2 + normalTime * 2;
        }

        public void Next()
        {
            time++;
            if(time == totalTime)
            {
                time = 0;
            }
        }

        public int getTimeToWait(int begin, string direction)
        {
            int sleepTime = 0;
            if (direction == "left")
            {
                if (begin % 2 == 0)
                {
                    if(time > yellowTime + normalTime || time < yellowTime + normalTime + leftTime)
                    {
                        sleepTime = 0;
                    }
                    else
                    {

                    }
                }
                else
                {

                }
            }
            else
            {
                if (begin % 2 == 0)
                {

                }
                else
                {

                }

            }

            return sleepTime * 1000 / 60;
        }


    }
}
